# Project2---G.231.21.0138
Project 2 Komputer Grafis - G.231.21.0138
